import 'package:flutter/material.dart';

void main() => runApp(const MnmGuideApp());

const navy = Color(0xFF102B50);
const red = Color(0xFFD62828);

class MnmGuideApp extends StatelessWidget {
  const MnmGuideApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MNM GUIDE',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const MainShell(),
    );
  }
}

class NewsItem {
  final String category, title, summary, time;
  const NewsItem(this.category, this.title, this.summary, this.time);
}

const sampleNews = <NewsItem>[
  NewsItem('ఆంధ్రప్రదేశ్', 'MNM GUIDEకు స్వాగతం', 'మీ ప్రాంతంలోని తాజా వార్తలు, ప్రజా సమస్యలు, ముఖ్యమైన సమాచారం ఇక్కడ తెలుసుకోండి.', 'ఇప్పుడే'),
  NewsItem('అనంతపురం', 'జిల్లా వార్తలు త్వరలో ఇక్కడ కనిపిస్తాయి', 'అడ్మిన్ ద్వారా ధృవీకరించిన వార్తలు మాత్రమే ప్రచురించబడతాయి.', 'తాజా'),
  NewsItem('కళ్యాణదుర్గం', 'మీ ప్రాంత వార్తలను మాతో పంచుకోండి', 'ప్రజలు పంపిన వార్తలను పరిశీలించిన తర్వాత ప్రచురిస్తాము.', 'తాజా'),
];

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [HomePage(), VideosPage(), SubmitPage(), AboutPage()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        title: const Row(children: [
          CircleAvatar(backgroundColor: Colors.white, child: Text('MNM', style: TextStyle(color: navy, fontWeight: FontWeight.w900, fontSize: 12))),
          SizedBox(width: 10),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('MNM GUIDE', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
            Text('తెలుగు డిజిటల్ న్యూస్', style: TextStyle(fontSize: 10, color: Colors.white70)),
          ]),
        ]),
        actions: [IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('నోటిఫికేషన్లు త్వరలో అందుబాటులోకి వస్తాయి.'))), icon: const Icon(Icons.notifications_none))],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'హోమ్'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'వీడియోలు'),
          NavigationDestination(icon: Icon(Icons.send_outlined), label: 'వార్త పంపండి'),
          NavigationDestination(icon: Icon(Icons.info_outline), label: 'మా గురించి'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(16)),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('ప్రజల గొంతుక – ప్రజల కోసం వార్తలు', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('నిజం కోసం.. ప్రజల పక్షాన..', style: TextStyle(color: Colors.white70)),
          ]),
        ),
        const SizedBox(height: 18),
        const Row(children: [
          Icon(Icons.bolt, color: red), SizedBox(width: 6),
          Text('బ్రేకింగ్ న్యూస్', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          Spacer(), Text('MNM GUIDE', style: TextStyle(color: navy, fontSize: 11, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 8),
        ...sampleNews.map((n) => Card(
          elevation: 0,
          margin: const EdgeInsets.only(bottom: 10),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4), decoration: BoxDecoration(color: const Color(0xFFFFE8E8), borderRadius: BorderRadius.circular(20)), child: Text(n.category, style: const TextStyle(color: red, fontSize: 11, fontWeight: FontWeight.bold))),
                const Spacer(), Text(n.time, style: const TextStyle(color: Colors.grey, fontSize: 11)),
              ]),
              const SizedBox(height: 9),
              Text(n.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text(n.summary, style: const TextStyle(color: Colors.black87, height: 1.4)),
            ]),
          ),
        )),
        const SizedBox(height: 8),
        const Text('వార్తల విభాగాలు', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: const [
          _CategoryChip('ఆంధ్రప్రదేశ్'), _CategoryChip('అనంతపురం'),
          _CategoryChip('కళ్యాణదుర్గం'), _CategoryChip('రాజకీయాలు'),
          _CategoryChip('క్రైమ్'), _CategoryChip('ప్రజా సమస్యలు'),
        ]),
      ],
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  const _CategoryChip(this.label);
  @override
  Widget build(BuildContext context) => Chip(avatar: const Icon(Icons.newspaper, size: 16), label: Text(label), backgroundColor: Colors.white);
}

class VideosPage extends StatelessWidget {
  const VideosPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    Text('వీడియో న్యూస్', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    SizedBox(height: 12),
    Card(child: Padding(padding: EdgeInsets.all(18), child: Column(children: [
      Icon(Icons.ondemand_video, size: 54, color: navy),
      SizedBox(height: 8),
      Text('MNM GUIDE వీడియోలు త్వరలో', style: TextStyle(fontWeight: FontWeight.bold)),
      Text('YouTube వీడియో లింకులు అడ్మిన్ ద్వారా ఇక్కడ జోడించవచ్చు.', textAlign: TextAlign.center),
    ]))),
  ]);
}

class SubmitPage extends StatefulWidget {
  const SubmitPage({super.key});
  @override
  State<SubmitPage> createState() => _SubmitPageState();
}

class _SubmitPageState extends State<SubmitPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final location = TextEditingController();
  final details = TextEditingController();
  @override
  void dispose() { name.dispose(); phone.dispose(); location.dispose(); details.dispose(); super.dispose(); }

  void submit() {
    if (name.text.trim().isEmpty || location.text.trim().isEmpty || details.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('పేరు, ప్రాంతం, వార్త వివరాలు నమోదు చేయండి.')));
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('డెమో: ఫారం సిద్ధంగా ఉంది. సర్వర్ అనుసంధానం తర్వాత వార్త పంపబడుతుంది.')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('మీ వార్త మాకు పంపండి', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('మీరు పంపిన వివరాలను పరిశీలించిన తర్వాతే ప్రచురిస్తాము.'),
    const SizedBox(height: 18),
    TextField(controller: name, decoration: const InputDecoration(labelText: 'మీ పేరు', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
    const SizedBox(height: 12),
    TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'మొబైల్ నంబర్ (ఐచ్ఛికం)', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
    const SizedBox(height: 12),
    TextField(controller: location, decoration: const InputDecoration(labelText: 'ప్రాంతం / గ్రామం', border: OutlineInputBorder(), prefixIcon: Icon(Icons.location_on))),
    const SizedBox(height: 12),
    TextField(controller: details, minLines: 5, maxLines: 8, decoration: const InputDecoration(labelText: 'వార్త వివరాలు', alignLabelWithHint: true, border: OutlineInputBorder())),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: submit, icon: const Icon(Icons.send), label: const Text('వార్త పంపండి'), style: FilledButton.styleFrom(backgroundColor: navy, padding: const EdgeInsets.all(15))),
    const SizedBox(height: 8),
    const Text('గమనిక: ఇది ప్రారంభ డెమో. ప్రస్తుతం ఫారం సర్వర్‌కు పంపబడదు.', style: TextStyle(color: Colors.grey, fontSize: 12)),
  ]);
}

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: Padding(
    padding: EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      CircleAvatar(radius: 38, backgroundColor: navy, child: Text('MNM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20))),
      SizedBox(height: 14),
      Text('MNM GUIDE', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: navy)),
      SizedBox(height: 6),
      Text('ప్రజల గొంతుక – ప్రజల కోసం వార్తలు', textAlign: TextAlign.center),
      SizedBox(height: 12),
      Text('తెలుగు డిజిటల్ న్యూస్ వేదిక', style: TextStyle(color: Colors.grey)),
    ]),
  ));
}
