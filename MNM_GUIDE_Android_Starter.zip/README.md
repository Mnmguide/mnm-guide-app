# MNM GUIDE Android app — starter

This is a Flutter starter project for the MNM GUIDE Telugu news app.

## Included in this first prototype
- Telugu home/news feed with sample placeholder stories
- News category chips
- Video news placeholder
- Public news submission form UI
- About page and bottom navigation

## Important current limitations
This is a UI prototype, not a production news service yet:
- News is sample/local data; there is no admin publishing backend.
- Submitted stories are not uploaded or stored.
- Push notifications are not connected.
- Video links are not yet managed from an admin panel.

These require a backend and secure admin access. A sensible free-tier next step is Firebase (Firestore for stories/submissions, Firebase Cloud Messaging for notifications, and Firebase Storage only if media uploads are needed). Free-tier quotas and terms can change; review them before launch.

## Run on Android
1. Install Flutter SDK and Android Studio.
2. Extract this project.
3. In this folder run: `flutter pub get`
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run: `flutter run`
6. To build an APK: `flutter build apk --release`
   APK output: `build/app/outputs/flutter-apk/app-release.apk`

## Before public launch
- Add Firebase project configuration for Android.
- Implement authenticated admin-only publishing.
- Store public submissions as pending; do not publish automatically.
- Add moderation, privacy notice, contact details, and abuse reporting.
- Configure FCM and test notifications on real devices.
- Add verified YouTube video URLs and editorial corrections/contact process.
